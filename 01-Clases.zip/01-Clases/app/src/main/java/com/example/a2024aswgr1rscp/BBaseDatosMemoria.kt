package com.example.a2024aswgr1rscp

class BBaseDatosMemoria {

    companion object{
        val arregloBEntrenador = arrayListOf<BEntrenador>()

        init {
            arregloBEntrenador
                .add( BEntrenador(1, "Adrian", "a@a.com"))
            arregloBEntrenador
                .add( BEntrenador(1, "Rafael", "b@b.com"))
            arregloBEntrenador
                .add( BEntrenador(1, "Sebastian", "c@c.com"))
        }
    }
}